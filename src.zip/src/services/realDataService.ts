import { API_CONFIG, CORS_PROXY, RATE_LIMITS } from '../config/apiConfig';
import { MarketData, NewsItem, CandlestickData, TechnicalIndicators } from '../types';

class RealDataService {
  private rateLimiters: Map<string, { count: number; resetTime: number }> = new Map();

  private async makeRequest(url: string, options: RequestInit = {}, service: string = ''): Promise<any> {
    // Check rate limits
    if (service && this.isRateLimited(service)) {
      throw new Error(`Rate limit exceeded for ${service}`);
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      // Update rate limiter
      if (service) {
        this.updateRateLimit(service);
      }

      return await response.json();
    } catch (error) {
      console.error(`API request failed for ${service}:`, error);
      throw error;
    }
  }

  private isRateLimited(service: string): boolean {
    const limiter = this.rateLimiters.get(service);
    const config = RATE_LIMITS[service as keyof typeof RATE_LIMITS];
    
    if (!limiter || !config) return false;
    
    const now = Date.now();
    if (now > limiter.resetTime) {
      this.rateLimiters.set(service, { count: 0, resetTime: now + config.window });
      return false;
    }
    
    return limiter.count >= config.requests;
  }

  private updateRateLimit(service: string): void {
    const limiter = this.rateLimiters.get(service) || { count: 0, resetTime: Date.now() + (RATE_LIMITS[service as keyof typeof RATE_LIMITS]?.window || 60000) };
    limiter.count++;
    this.rateLimiters.set(service, limiter);
  }

  // CoinMarketCap API
  async getCoinMarketCapData(): Promise<MarketData[]> {
    const config = API_CONFIG.coinmarketcap.primary;
    const url = `${config.baseUrl}/cryptocurrency/quotes/latest?symbol=BTC,ETH,BNB,ADA,SOL,MATIC,DOT,LINK,LTC,XRP&convert=USD`;
    
    try {
      const data = await this.makeRequest(url, {
        headers: {
          'X-CMC_PRO_API_KEY': config.key,
        },
      }, 'coinmarketcap');

      return this.transformCMCData(data.data);
    } catch (error) {
      console.error('CoinMarketCap API failed, trying fallback:', error);
      return this.getCoinMarketCapFallback();
    }
  }

  private async getCoinMarketCapFallback(): Promise<MarketData[]> {
    const config = API_CONFIG.coinmarketcap.fallback;
    const url = `${config.baseUrl}/cryptocurrency/quotes/latest?symbol=BTC,ETH,BNB,ADA,SOL&convert=USD`;
    
    const data = await this.makeRequest(url, {
      headers: {
        'X-CMC_PRO_API_KEY': config.key,
      },
    }, 'coinmarketcap');

    return this.transformCMCData(data.data);
  }

  private transformCMCData(data: any): MarketData[] {
    return Object.values(data).map((coin: any) => ({
      id: coin.slug,
      symbol: coin.symbol,
      name: coin.name,
      price: coin.quote.USD.price,
      change24h: coin.quote.USD.price * (coin.quote.USD.percent_change_24h / 100),
      changePercent24h: coin.quote.USD.percent_change_24h,
      volume24h: coin.quote.USD.volume_24h,
      marketCap: coin.quote.USD.market_cap,
      high24h: coin.quote.USD.price * 1.05, // Approximate
      low24h: coin.quote.USD.price * 0.95, // Approximate
      timestamp: Date.now()
    }));
  }

  // CryptoCompare API for historical data
  async getCryptoCompareHistorical(symbol: string, limit: number = 100): Promise<CandlestickData[]> {
    const config = API_CONFIG.cryptocompare.primary;
    const url = `${config.baseUrl}/v2/histohour?fsym=${symbol}&tsym=USD&limit=${limit}&api_key=${config.key}`;
    
    const data = await this.makeRequest(url, {}, 'cryptocompare');
    
    return data.Data.Data.map((item: any) => ({
      time: item.time * 1000,
      open: item.open,
      high: item.high,
      low: item.low,
      close: item.close,
      volume: item.volumeto
    }));
  }

  // CoinGecko API (free tier)
  async getCoinGeckoData(): Promise<MarketData[]> {
    const config = API_CONFIG.sentiment.coingecko;
    const url = `${config.baseUrl}/simple/price?ids=bitcoin,ethereum,binancecoin,cardano,solana,polygon,polkadot,chainlink,litecoin,ripple&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_market_cap=true`;
    
    try {
      const data = await this.makeRequest(url, {}, 'coingecko');
      return this.transformCoinGeckoData(data);
    } catch (error) {
      console.error('CoinGecko API failed:', error);
      throw error;
    }
  }

  private transformCoinGeckoData(data: any): MarketData[] {
    const symbolMap: { [key: string]: string } = {
      'bitcoin': 'BTC',
      'ethereum': 'ETH',
      'binancecoin': 'BNB',
      'cardano': 'ADA',
      'solana': 'SOL',
      'polygon': 'MATIC',
      'polkadot': 'DOT',
      'chainlink': 'LINK',
      'litecoin': 'LTC',
      'ripple': 'XRP'
    };

    return Object.entries(data).map(([id, coin]: [string, any]) => ({
      id,
      symbol: symbolMap[id] || id.toUpperCase(),
      name: id.charAt(0).toUpperCase() + id.slice(1),
      price: coin.usd,
      change24h: coin.usd * (coin.usd_24h_change / 100),
      changePercent24h: coin.usd_24h_change || 0,
      volume24h: coin.usd_24h_vol || 0,
      marketCap: coin.usd_market_cap || 0,
      high24h: coin.usd * 1.05,
      low24h: coin.usd * 0.95,
      timestamp: Date.now()
    }));
  }

  // News API
  async getCryptoNews(): Promise<NewsItem[]> {
    const config = API_CONFIG.newsapi.primary;
    const url = `${config.baseUrl}/everything?q=cryptocurrency OR bitcoin OR ethereum&sortBy=publishedAt&pageSize=20&apiKey=${config.key}`;
    
    try {
      const data = await this.makeRequest(url, {}, 'newsapi');
      return this.transformNewsData(data.articles);
    } catch (error) {
      console.error('NewsAPI failed, trying Reddit fallback:', error);
      return this.getRedditNews();
    }
  }

  private transformNewsData(articles: any[]): NewsItem[] {
    return articles.map((article, index) => ({
      id: `news-${index}`,
      title: article.title,
      description: article.description || '',
      url: article.url,
      source: article.source.name,
      publishedAt: article.publishedAt,
      sentiment: this.analyzeSentiment(article.title + ' ' + article.description),
      impact: this.determineImpact(article.title)
    }));
  }

  private analyzeSentiment(text: string): 'positive' | 'negative' | 'neutral' {
    const positiveWords = ['bull', 'rise', 'gain', 'up', 'surge', 'rally', 'growth', 'adoption', 'breakthrough'];
    const negativeWords = ['bear', 'fall', 'drop', 'crash', 'decline', 'loss', 'hack', 'ban', 'regulation'];
    
    const lowerText = text.toLowerCase();
    const positiveCount = positiveWords.filter(word => lowerText.includes(word)).length;
    const negativeCount = negativeWords.filter(word => lowerText.includes(word)).length;
    
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  private determineImpact(title: string): 'high' | 'medium' | 'low' {
    const highImpactWords = ['etf', 'regulation', 'ban', 'hack', 'crash', 'surge', 'adoption', 'institutional'];
    const mediumImpactWords = ['price', 'market', 'trading', 'volume', 'analysis'];
    
    const lowerTitle = title.toLowerCase();
    
    if (highImpactWords.some(word => lowerTitle.includes(word))) return 'high';
    if (mediumImpactWords.some(word => lowerTitle.includes(word))) return 'medium';
    return 'low';
  }

  // Reddit fallback for news
  private async getRedditNews(): Promise<NewsItem[]> {
    const config = API_CONFIG.sentiment.reddit;
    const url = `${config.baseUrl}/r/CryptoCurrency/hot.json?limit=10`;
    
    try {
      const data = await this.makeRequest(url);
      return data.data.children.map((post: any, index: number) => ({
        id: `reddit-${post.data.id}`,
        title: post.data.title,
        description: post.data.selftext?.substring(0, 200) || '',
        url: `https://reddit.com${post.data.permalink}`,
        source: 'Reddit',
        publishedAt: new Date(post.data.created_utc * 1000).toISOString(),
        sentiment: this.analyzeSentiment(post.data.title),
        impact: this.determineImpact(post.data.title)
      }));
    } catch (error) {
      console.error('Reddit API failed:', error);
      return [];
    }
  }

  // Fear & Greed Index
  async getFearGreedIndex(): Promise<{ value: number; classification: string }> {
    const config = API_CONFIG.sentiment.fearGreed;
    const url = `${config.baseUrl}/?limit=1&format=json`;
    
    try {
      const data = await this.makeRequest(url);
      return {
        value: parseInt(data.data[0].value),
        classification: data.data[0].value_classification
      };
    } catch (error) {
      console.error('Fear & Greed Index failed:', error);
      return { value: 50, classification: 'Neutral' };
    }
  }

  // Technical Indicators (calculated from price data)
  calculateTechnicalIndicators(data: CandlestickData[]): TechnicalIndicators {
    if (data.length < 50) {
      throw new Error('Insufficient data for technical indicators');
    }

    const closes = data.map(d => d.close);
    const highs = data.map(d => d.high);
    const lows = data.map(d => d.low);
    const volumes = data.map(d => d.volume);

    return {
      rsi: this.calculateRSI(closes, 14),
      macd: this.calculateMACD(closes),
      sma20: this.calculateSMA(closes, 20),
      sma50: this.calculateSMA(closes, 50),
      ema12: this.calculateEMA(closes, 12),
      ema26: this.calculateEMA(closes, 26),
      bb: this.calculateBollingerBands(closes, 20, 2)
    };
  }

  private calculateRSI(prices: number[], period: number): number {
    const gains: number[] = [];
    const losses: number[] = [];

    for (let i = 1; i < prices.length; i++) {
      const change = prices[i] - prices[i - 1];
      gains.push(change > 0 ? change : 0);
      losses.push(change < 0 ? Math.abs(change) : 0);
    }

    const avgGain = gains.slice(-period).reduce((a, b) => a + b, 0) / period;
    const avgLoss = losses.slice(-period).reduce((a, b) => a + b, 0) / period;

    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  private calculateMACD(prices: number[]): { macd: number; signal: number; histogram: number } {
    const ema12 = this.calculateEMA(prices, 12);
    const ema26 = this.calculateEMA(prices, 26);
    const macd = ema12 - ema26;
    
    // Simplified signal line (would need EMA of MACD in real implementation)
    const signal = macd * 0.9;
    const histogram = macd - signal;

    return { macd, signal, histogram };
  }

  private calculateSMA(prices: number[], period: number): number {
    const slice = prices.slice(-period);
    return slice.reduce((a, b) => a + b, 0) / slice.length;
  }

  private calculateEMA(prices: number[], period: number): number {
    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }

    return ema;
  }

  private calculateBollingerBands(prices: number[], period: number, stdDev: number): { upper: number; middle: number; lower: number } {
    const sma = this.calculateSMA(prices, period);
    const slice = prices.slice(-period);
    const variance = slice.reduce((acc, price) => acc + Math.pow(price - sma, 2), 0) / period;
    const standardDeviation = Math.sqrt(variance);

    return {
      upper: sma + (standardDeviation * stdDev),
      middle: sma,
      lower: sma - (standardDeviation * stdDev)
    };
  }
}

export const realDataService = new RealDataService();