CreptoAI Monitoring - Starter Bundle
===================================

Contents:
- grafana/creptoai-dashboard.json
- prometheus/prometheus.yml
- alerting/creptoai-alert-rules.yml
- docker-compose.yml
- scripts/verify-monitoring.sh
- prometheus-client.ts (sample instrumentation)

Quick start (local)
-------------------
1. Ensure backend exposes metrics at http://localhost:5000/metrics (see prometheus-client.ts).
2. Run the monitoring stack:
   docker-compose up -d

3. Open Grafana: http://localhost:3000 (admin/admin)
4. Import dashboard:
   - UI: Dashboards -> Import -> Upload creptoai-dashboard.json
   - Or via API:
     curl -u admin:admin -X POST -H "Content-Type: application/json" http://localhost:3000/api/dashboards/db -d @grafana/creptoai-dashboard.json

Verification
------------
Run the verification script:
  bash monitoring/scripts/verify-monitoring.sh

Notes
-----
- Replace host.docker.internal with localhost if running without Docker.
- Add your Alertmanager config and integrate Slack/PagerDuty webhooks in alerting/alertmanager.yml.
