#!/usr/bin/env bash
set -e
echo "Bringing up docker stack..."
docker-compose -f ../docker-compose.yml up -d
echo "Waiting for Prometheus..."
sleep 5
echo "Prometheus targets:"
curl -s http://localhost:9090/api/v1/targets | jq '.'
echo "Query example (up):"
curl -s 'http://localhost:9090/api/v1/query?query=up' | jq '.'
echo "Import dashboard to Grafana (requires admin:admin):"
curl -s -X POST -H "Content-Type: application/json" -u admin:admin http://localhost:3000/api/dashboards/db -d @../grafana/creptoai-dashboard.json
echo "Done. Open Grafana at http://localhost:3000"
