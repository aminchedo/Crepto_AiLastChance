import express from 'express';
import client from 'prom-client';

const collectDefaultMetrics = client.collectDefaultMetrics;
collectDefaultMetrics({ timeout: 5000 });

const register = client.register;

const apiRequestCounter = new client.Counter({
  name: 'api_requests_total',
  help: 'Total number of API requests',
  labelNames: ['service', 'endpoint', 'status'],
});

const apiErrorCounter = new client.Counter({
  name: 'api_errors_total',
  help: 'Total number of API errors',
  labelNames: ['service', 'endpoint'],
});

const apiDuration = new client.Histogram({
  name: 'api_request_duration_seconds',
  help: 'API request duration in seconds',
  labelNames: ['service','endpoint'],
  buckets: [0.005,0.01,0.05,0.1,0.5,1,2,5]
});

export function metricsMiddleware(serviceName: string) {
  return async (req, res, next) => {
    const end = apiDuration.startTimer({ service: serviceName, endpoint: req.path });
    res.on('finish', () => {
      end();
      apiRequestCounter.inc({ service: serviceName, endpoint: req.path, status: res.statusCode });
      if (res.statusCode >= 500) {
        apiErrorCounter.inc({ service: serviceName, endpoint: req.path });
      }
    });
    next();
  };
}

export function setupMetrics(app: express.Express) {
  app.get('/metrics', async (_req, res) => {
    res.set('Content-Type', register.contentType);
    res.send(await register.metrics());
  });
}
